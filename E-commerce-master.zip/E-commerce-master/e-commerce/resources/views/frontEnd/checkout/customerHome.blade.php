@extends('frontEnd.master')
@section('mainContent')
<hr/><br><br><hr>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="well lead text-center text-success"> 
                <h1>Thanks for you order. We will process it soon....</h1>
            </div>
        </div>
    </div>
</div><br><br><br><br><br><br>
<br><br><br><br><br><br>

@endsection