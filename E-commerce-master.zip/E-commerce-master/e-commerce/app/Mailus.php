<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mailus extends Model
{
    //
}
